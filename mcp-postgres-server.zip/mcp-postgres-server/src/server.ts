import { McpServer } from '@modelcontextprotocol/server';
import * as z from 'zod/v4';
import pg from 'pg';

const defaultPool = new pg.Pool({ connectionString: process.env.DATABASE_URL });

/** The read-only rule, in one place: only SELECT may reach the database. */
export function assertReadOnly(sql: string): void {
  if (!sql.trim().toUpperCase().startsWith('SELECT')) {
    throw new Error('Read-only: SELECT only.');
  }
}

// A pool is anything with a query method: the real pg.Pool in production,
// the pg-mem pool in tests. No cast needed either way.
export type QueryablePool = {
  query: (sql: string, params?: unknown[]) => Promise<{ rows: any[] }>;
};

export function createServer(pool: QueryablePool = defaultPool): McpServer {
  const server = new McpServer({ name: 'postgres-db', version: '1.0.0' });

  async function queryReadOnly(sql: string, params: unknown[] = []) {
    assertReadOnly(sql);
    try {
      return await pool.query(sql, params);
    } catch (error) {
      console.error('Database query failed:', error);
      throw new Error('The database could not be reached. Check that Postgres is running and DATABASE_URL is correct.');
    }
  }

  server.registerTool('list_tables', {
    description: 'List all tables in the public schema of the database.',
    inputSchema: z.object({}),
  }, async () => {
    const result = await queryReadOnly(
      "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' ORDER BY table_name");
    const names = result.rows.map((r) => r.table_name).join(', ');
    return { content: [{ type: 'text', text: `Tables: ${names}` }] };
  });

  server.registerTool('query_customers', {
    description: 'List customers from a country, up to a limit. Read-only.',
    inputSchema: z.object({
      country: z.string().describe('Country to filter by, for example India'),
      limit: z.number().int().min(1).max(100).default(10),
    }),
  }, async ({ country, limit }) => {
    const result = await queryReadOnly(
      'SELECT id, name, country FROM customers WHERE country = $1 LIMIT $2',
      [country, limit]);
    return { content: [{ type: 'text', text: JSON.stringify(result.rows, null, 2) }] };
  });

  server.registerTool('list_columns', {
    description: 'List the columns of one table, with their data types. Read-only.',
    inputSchema: z.object({
      table: z.string().describe('Table name, for example customers'),
    }),
  }, async ({ table }) => {
    const result = await queryReadOnly(
      "SELECT column_name, data_type FROM information_schema.columns WHERE table_schema = 'public' AND table_name = $1 ORDER BY ordinal_position",
      [table]);
    if (result.rows.length === 0) {
      return { content: [{ type: 'text', text: `No table named ${table} in the public schema.` }], isError: true };
    }
    return { content: [{ type: 'text', text: JSON.stringify(result.rows, null, 2) }] };
  });

  server.registerTool('count_rows', {
    description: 'Count the rows in one table. Read-only.',
    inputSchema: z.object({
      table: z.string().describe('Table name, for example customers'),
    }),
  }, async ({ table }) => {
    // A table name is an identifier, not a value, so it cannot be a $1
    // placeholder. Check it against the allowlist first, then quote it.
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(table)) {
      return { content: [{ type: 'text', text: `Invalid table name: ${table}` }], isError: true };
    }
    const found = await queryReadOnly(
      "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_name = $1",
      [table]);
    if (found.rows.length === 0) {
      return { content: [{ type: 'text', text: `No table named ${table} in the public schema.` }], isError: true };
    }
    const result = await queryReadOnly(`SELECT COUNT(*)::int AS count FROM "${table}"`);
    return { content: [{ type: 'text', text: `Table ${table} has ${result.rows[0].count} rows.` }] };
  });

  server.registerResource('customers-schema', 'db://customers/schema', {
    title: 'Customers table schema',
    description: 'Column names and types of the customers table.',
    mimeType: 'text/plain',
  }, async (uri) => {
    const result = await queryReadOnly(
      "SELECT column_name, data_type FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'customers' ORDER BY ordinal_position");
    const lines = result.rows.map((r) => `${r.column_name}: ${r.data_type}`).join('\n');
    return { contents: [{ uri: uri.href, mimeType: 'text/plain', text: `customers\n${lines}` }] };
  });

  server.registerPrompt('summarize-customers-by-country', {
    title: 'Summarize customers by country',
    description: 'Ask for a per-country summary of the customers table.',
    argsSchema: z.object({}),
  }, () => ({
    messages: [{
      role: 'user' as const,
      content: {
        type: 'text' as const,
        text: 'Summarize our customers by country. For each country, say how many customers we have and list their names. Use the query_customers tool, one call per country, and the count_rows tool to double-check each total.',
      },
    }],
  }));

  return server;
}
