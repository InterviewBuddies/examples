import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { newDb } from 'pg-mem';
import { Client } from '@modelcontextprotocol/client';
import { InMemoryTransport } from '@modelcontextprotocol/server';
import { createServer, assertReadOnly } from '../src/server.js';

// Same demo data as the video: five customers, three in India.
const db = newDb();
db.public.none(`CREATE TABLE customers (id INT PRIMARY KEY, name TEXT, country TEXT);
INSERT INTO customers VALUES (1, 'Asha Patel', 'India'), (2, 'Rohan Mehta', 'India'),
  (3, 'Priya Nair', 'India'), (4, 'Emma Wilson', 'USA'), (5, 'Liam Brown', 'USA');`);
const { Pool } = db.adapters.createPg();
const pool = new Pool();

let client: Client;
before(async () => {
  const server = createServer(pool);
  const [clientTransport, serverTransport] = InMemoryTransport.createLinkedPair();
  client = new Client({ name: 'test', version: '1.0.0' }, { capabilities: {} });
  await Promise.all([client.connect(clientTransport), server.connect(serverTransport)]);
});
after(async () => { await client.close(); });

function textOf(result: { content: { type: string; text?: string }[] }): string {
  return result.content.map((c) => c.text ?? '').join('');
}

test('lists all four tools', async () => {
  const names = (await client.listTools()).tools.map((t) => t.name);
  assert.deepEqual(names, ['list_tables', 'query_customers', 'list_columns', 'count_rows']);
});

test('list_tables returns customers', async () => {
  assert.equal(textOf(await client.callTool({ name: 'list_tables', arguments: {} }) as never), 'Tables: customers');
});

test('query_customers for India returns three rows', async () => {
  const rows = JSON.parse(textOf(await client.callTool({ name: 'query_customers', arguments: { country: 'India' } }) as never));
  assert.equal(rows.length, 3);
  assert.deepEqual(rows.map((r: { name: string }) => r.name), ['Asha Patel', 'Rohan Mehta', 'Priya Nair']);
});

test('injection string as the country returns zero rows', async () => {
  const rows = JSON.parse(textOf(await client.callTool({
    name: 'query_customers', arguments: { country: "India' OR '1'='1" },
  }) as never));
  assert.equal(rows.length, 0);
});

test('list_columns returns id, name and country', async () => {
  const cols = JSON.parse(textOf(await client.callTool({ name: 'list_columns', arguments: { table: 'customers' } }) as never));
  assert.deepEqual(cols.map((c: { column_name: string }) => c.column_name), ['id', 'name', 'country']);
});

test('count_rows counts five customers', async () => {
  assert.equal(textOf(await client.callTool({ name: 'count_rows', arguments: { table: 'customers' } }) as never),
    'Table customers has 5 rows.');
});

test('count_rows rejects an injected table name and the table survives', async () => {
  const bad = await client.callTool({
    name: 'count_rows', arguments: { table: 'customers; DROP TABLE customers; --' },
  }) as { isError?: boolean };
  assert.equal(bad.isError, true);
  assert.equal(textOf(await client.callTool({ name: 'count_rows', arguments: { table: 'customers' } }) as never),
    'Table customers has 5 rows.');
});

test('read-only guard rejects DELETE and accepts SELECT', () => {
  assert.throws(() => assertReadOnly('DELETE FROM customers'), /Read-only: SELECT only/);
  assert.doesNotThrow(() => assertReadOnly('SELECT id FROM customers'));
});

test('zod rejects a limit above one hundred', async () => {
  const result = await client.callTool({
    name: 'query_customers', arguments: { country: 'India', limit: 500 },
  }) as { isError?: boolean };
  assert.equal(result.isError, true);
  assert.match(textOf(result as never), /Too big: expected number to be <=100/);
});

test('customers schema resource reads back the columns', async () => {
  const read = await client.readResource({ uri: 'db://customers/schema' });
  assert.match((read.contents[0] as { text: string }).text, /id: integer\nname: text\ncountry: text/);
});

test('summarize prompt returns one user message', async () => {
  const prompt = await client.getPrompt({ name: 'summarize-customers-by-country' });
  assert.equal(prompt.messages.length, 1);
  assert.match((prompt.messages[0].content as { text: string }).text, /Summarize our customers by country/);
});
