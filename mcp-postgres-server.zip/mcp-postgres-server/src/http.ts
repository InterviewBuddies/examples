import { createMcpHandler } from '@modelcontextprotocol/server';
import { toNodeHandler } from '@modelcontextprotocol/node';
import http from 'node:http';
import { createServer } from './server.js';

// The handler does no authentication itself. Check a token before it runs,
// and never expose this on the open internet without real auth in front.
const handler = createMcpHandler(() => createServer());
const nodeHandler = toNodeHandler(handler);

const server = http.createServer(async (req, res) => {
  if (req.url !== '/mcp') {
    res.writeHead(404);
    res.end('Not found');
    return;
  }
  if (req.headers.authorization !== `Bearer ${process.env.MCP_TOKEN}`) {
    res.writeHead(401);
    res.end('Unauthorized');
    return;
  }
  await nodeHandler(req, res);
});

server.listen(3000, () => {
  console.error('postgres-db: listening on http://localhost:3000/mcp');
});
