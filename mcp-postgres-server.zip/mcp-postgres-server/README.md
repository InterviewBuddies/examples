# MCP Postgres Server

Code from the InterviewBuddies video: [How to Create an MCP Server and Connect It to Your Database](https://www.youtube.com/@InterviewBuddies) (21 min).

A small MCP (Model Context Protocol) server in TypeScript that gives an AI assistant a safe, **read-only** window into a Postgres database.

## What it does

Four tools, one resource, one prompt:

- `list_tables` — list tables in the public schema
- `query_customers` — list customers from a country, up to a limit (parameterized, `$1` / `$2`)
- `list_columns` — columns + types for one table
- `count_rows` — count rows in one table (table name checked against an allowlist first — identifiers can't be `$1` placeholders)
- Resource `db://customers/schema` — the customers table schema
- Prompt `summarize-customers-by-country` — per-country summary

## Setup

Node 20+ required.

```bash
npm install
```

## Run it (local, stdio)

```bash
DATABASE_URL=postgresql://user:password@localhost:5432/mydb npx tsx src/stdio.ts
```

Logs go to stderr only — stdout carries the protocol.

## Run it (HTTP, for a team)

```bash
MCP_TOKEN=your-secret-token DATABASE_URL=postgresql://user:password@localhost:5432/mydb npx tsx src/http.ts
```

Serves at `http://localhost:3000/mcp` — anything not at `/mcp` returns 404, requests without the Bearer token return 401. The handler does no auth itself: never expose this on the open internet without real auth in front of it.

## Connect it

**Claude Desktop** — in `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "postgres-db": {
      "command": "npx",
      "args": ["tsx", "/absolute/path/mcp-postgres-server/src/stdio.ts"],
      "env": { "DATABASE_URL": "postgresql://user:password@localhost:5432/mydb" }
    }
  }
}
```

**Claude Code:**

```bash
claude mcp add postgres-db -e DATABASE_URL=... -- npx tsx /absolute/path/mcp-postgres-server/src/stdio.ts
```

**Test it first — MCP Inspector:**

```bash
npx @modelcontextprotocol/inspector npx tsx src/stdio.ts
```

## Tests

11 checks (read-only guard, both injection cases, tools, resource, prompt) against in-memory Postgres:

```bash
npm test
```

## Safety rules

1. Parameterized queries only (`$1`, `$2`) — never build SQL by joining strings.
2. Table names are identifiers, not values — allowlist them, then quote them.
3. Read-only — only `SELECT`; anything else is refused.
4. Secrets in environment variables only — never in code or committed config.
5. Never expose a database server over HTTP without authentication in front of it.

## Demo data

Customers table (`id`, `name`, `country`): Asha Patel (India), Rohan Mehta (India), Priya Nair (India), Emma Wilson (USA), Liam Brown (USA). Ask: "Show me the customers in India" — three rows back.
