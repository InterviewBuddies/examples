import { serveStdio } from '@modelcontextprotocol/server/stdio';
import { createServer } from './server.js';

console.error('postgres-db: listening on stdio');
void serveStdio(createServer);
